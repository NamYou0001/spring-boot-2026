package com.you.springsecurity.repository;

import com.you.springsecurity.model.RefreshToken;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

public interface RefreshTokenRepository extends JpaRepository<RefreshToken, Long> {

    @Query("""
            SELECT rt
            FROM RefreshToken rt
            JOIN FETCH rt.user
            WHERE rt.tokenHash = :tokenHash
            """)
    Optional<RefreshToken> findByTokenHashWithUser(@Param("tokenHash") String tokenHash);

    List<RefreshToken> findByFamilyId(String familyId);

    Optional<RefreshToken> findBySessionId(String sessionId);

    @Modifying
    @Query("""
            UPDATE RefreshToken rt
            SET rt.revokedAt = :revokedAt, rt.revokedReason = :reason
            WHERE rt.familyId = :familyId AND rt.revokedAt IS NULL
            """)
    int revokeFamily(@Param("familyId") String familyId, @Param("revokedAt") Instant revokedAt, @Param("reason") String reason);

    @Modifying
    @Query("""
            UPDATE RefreshToken rt
            SET rt.revokedAt = :revokedAt, rt.revokedReason = :reason
            WHERE rt.user.id = :userId AND rt.revokedAt IS NULL
            """)
    int revokeAllByUserId(@Param("userId") Long userId, @Param("revokedAt") Instant revokedAt, @Param("reason") String reason);

    @Modifying
    @Query("""
            UPDATE RefreshToken rt
            SET rt.revokedAt = :revokedAt, rt.revokedReason = :reason
            WHERE rt.sessionId = :sessionId AND rt.revokedAt IS NULL
            """)
    int revokeBySessionId(@Param("sessionId") String sessionId, @Param("revokedAt") Instant revokedAt, @Param("reason") String reason);

    @Query("""
            SELECT rt
            FROM RefreshToken rt
            WHERE rt.user.id = :userId
              AND rt.revokedAt IS NULL
              AND rt.expiresAt > :now
            ORDER BY rt.createdAt DESC
            """)
    List<RefreshToken> findActiveSessionsByUserId(@Param("userId") Long userId, @Param("now") Instant now);
}
