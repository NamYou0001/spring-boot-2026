package com.you.springsecurity.token;

import com.you.springsecurity.config.RefreshTokenProperties;
import com.you.springsecurity.dto.SessionResponse;
import com.you.springsecurity.exception.InvalidRefreshTokenException;
import com.you.springsecurity.exception.TokenReuseException;
import com.you.springsecurity.model.RefreshToken;
import com.you.springsecurity.model.Users;
import com.you.springsecurity.repository.RefreshTokenRepository;
import com.you.springsecurity.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.Base64;
import java.util.HexFormat;
import java.util.List;
import java.util.UUID;

@Service
public class RefreshTokenService {

    private static final Logger log = LoggerFactory.getLogger(RefreshTokenService.class);

    private final RefreshTokenRepository refreshTokenRepository;
    private final UserRepository userRepository;
    private final RefreshTokenProperties properties;
    private final SecureRandom secureRandom;

    public RefreshTokenService(RefreshTokenRepository refreshTokenRepository,
                               UserRepository userRepository,
                               RefreshTokenProperties properties) {
        this.refreshTokenRepository = refreshTokenRepository;
        this.userRepository = userRepository;
        this.properties = properties;
        this.secureRandom = new SecureRandom();
    }

    public record RotatedTokenResult(IssuedRefreshToken issuedRefreshToken, Users user) {}

    // ==========================================
    // 1. Generate & Save Initial Refresh Token
    // ==========================================
    @Transactional
    public IssuedRefreshToken createForUser(Long userId, String deviceInfo, String ipAddress) {
        Users user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalStateException("User not found with id: " + userId));

        String rawToken = generateRawToken();
        String tokenHash = hashToken(rawToken);
        Instant expiresAt = Instant.now().plus(properties.ttl());

        String familyId = UUID.randomUUID().toString();
        String sessionId = UUID.randomUUID().toString();

        RefreshToken refreshToken = new RefreshToken(
                user,
                tokenHash,
                familyId,
                sessionId,
                deviceInfo != null ? deviceInfo : "Unknown Device",
                ipAddress != null ? ipAddress : "0.0.0.0",
                expiresAt
        );

        refreshTokenRepository.save(refreshToken);

        return new IssuedRefreshToken(rawToken, expiresAt, familyId, sessionId);
    }

    @Transactional
    public IssuedRefreshToken createForUser(Long userId) {
        return createForUser(userId, "Unknown Device", "0.0.0.0");
    }

    // ==========================================
    // 2. Refresh Token Rotation & Reuse Detection
    // ==========================================
    @Transactional
    public RotatedTokenResult rotateRefreshToken(String rawToken, String clientDevice, String clientIp) {
        if (rawToken == null || rawToken.isBlank()) {
            throw new InvalidRefreshTokenException("Refresh token cannot be empty");
        }

        String tokenHash = hashToken(rawToken);
        RefreshToken storedToken = refreshTokenRepository.findByTokenHashWithUser(tokenHash)
                .orElseThrow(() -> new InvalidRefreshTokenException("Invalid refresh token"));

        Instant now = Instant.now();

        // 2.1 Check Token Reuse Detection
        if (storedToken.isRevoked()) {
            log.warn("SECURITY ALERT: Compromised refresh token reused! Token ID: {}, Family: {}, User: {}",
                    storedToken.getId(), storedToken.getFamilyId(), storedToken.getUser().getUsername());

            // Revoke entire token family
            refreshTokenRepository.revokeFamily(storedToken.getFamilyId(), now, "REUSE_DETECTED");

            throw new TokenReuseException(
                    "Token reuse detected. All sessions associated with this token lineage have been revoked for security.",
                    storedToken.getFamilyId()
            );
        }

        // 2.2 Check Expiration
        if (storedToken.isExpired(now)) {
            throw new InvalidRefreshTokenException("Refresh token has expired. Please login again.");
        }

        // 2.3 Check User Status
        Users user = storedToken.getUser();
        if (!user.isEnable() || !user.isAccountNonlocked()) {
            throw new InvalidRefreshTokenException("User account is inactive or locked");
        }

        // 2.4 Perform Rotation
        String newRawToken = generateRawToken();
        String newTokenHash = hashToken(newRawToken);
        Instant newExpiresAt = now.plus(properties.ttl());

        String deviceInfo = clientDevice != null ? clientDevice : storedToken.getDeviceInfo();
        String ipAddress = clientIp != null ? clientIp : storedToken.getIpAddress();

        // Create new token inheriting familyId and sessionId
        RefreshToken newRefreshToken = new RefreshToken(
                user,
                newTokenHash,
                storedToken.getFamilyId(),
                storedToken.getSessionId(),
                deviceInfo,
                ipAddress,
                newExpiresAt
        );

        // Revoke old token and mark replacedBy
        storedToken.replaceWith(newTokenHash, now);

        refreshTokenRepository.save(storedToken);
        refreshTokenRepository.save(newRefreshToken);

        IssuedRefreshToken issued = new IssuedRefreshToken(
                newRawToken,
                newExpiresAt,
                storedToken.getFamilyId(),
                storedToken.getSessionId()
        );

        return new RotatedTokenResult(issued, user);
    }

    // ==========================================
    // 3. Backward Compatible Validate
    // ==========================================
    @Transactional(readOnly = true)
    public RefreshToken validate(String rawToken) {
        if (rawToken == null || rawToken.isBlank()) {
            throw new InvalidRefreshTokenException("Refresh token is required");
        }

        String tokenHash = hashToken(rawToken);
        RefreshToken storedToken = refreshTokenRepository.findByTokenHashWithUser(tokenHash)
                .orElseThrow(() -> new InvalidRefreshTokenException("Invalid refresh token"));

        Instant now = Instant.now();
        if (storedToken.isExpired(now)) {
            throw new InvalidRefreshTokenException("Refresh token is expired");
        }

        if (storedToken.isRevoked()) {
            throw new InvalidRefreshTokenException("Refresh token has been revoked");
        }

        Users user = storedToken.getUser();
        if (!user.isEnable() || !user.isAccountNonlocked()) {
            throw new InvalidRefreshTokenException("User account is inactive or locked");
        }

        return storedToken;
    }

    // ==========================================
    // 4. Logout Current Session
    // ==========================================
    @Transactional
    public void revokeToken(String rawToken) {
        if (rawToken == null || rawToken.isBlank()) {
            return;
        }

        String tokenHash = hashToken(rawToken);
        refreshTokenRepository.findByTokenHashWithUser(tokenHash).ifPresent(token -> {
            if (!token.isRevoked()) {
                token.revoke(Instant.now(), "USER_LOGOUT");
                refreshTokenRepository.save(token);
            }
        });
    }

    // ==========================================
    // 5. Logout All Sessions for User
    // ==========================================
    @Transactional
    public void revokeAllForUser(Long userId) {
        refreshTokenRepository.revokeAllByUserId(userId, Instant.now(), "LOGOUT_ALL");
    }

    // ==========================================
    // 6. Terminate Specific Session
    // ==========================================
    @Transactional
    public void revokeSession(Long userId, String sessionId) {
        RefreshToken token = refreshTokenRepository.findBySessionId(sessionId)
                .orElseThrow(() -> new IllegalArgumentException("Session not found: " + sessionId));

        if (!token.getUser().getId().equals(userId)) {
            throw new IllegalArgumentException("Session does not belong to the authenticated user");
        }

        refreshTokenRepository.revokeBySessionId(sessionId, Instant.now(), "SESSION_TERMINATED");
    }

    // ==========================================
    // 7. Get Active User Sessions
    // ==========================================
    @Transactional(readOnly = true)
    public List<SessionResponse> getActiveSessions(Long userId) {
        return refreshTokenRepository.findActiveSessionsByUserId(userId, Instant.now())
                .stream()
                .map(token -> new SessionResponse(
                        token.getSessionId(),
                        token.getDeviceInfo(),
                        token.getIpAddress(),
                        token.getCreatedAt(),
                        token.getExpiresAt()
                ))
                .toList();
    }

    // ==========================================
    // Helper: Secure Random & Hashing
    // ==========================================
    private String generateRawToken() {
        byte[] randomBytes = new byte[64];
        secureRandom.nextBytes(randomBytes);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(randomBytes);
    }

    private String hashToken(String rawToken) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hash = digest.digest(rawToken.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(hash);
        } catch (NoSuchAlgorithmException exception) {
            throw new IllegalStateException("SHA-256 algorithm is unavailable", exception);
        }
    }
}
