package com.you.springsecurity.dto;

public record LoginRequest
        (
                String username ,
                String password
        ){

}
