package com.you.springsecurity.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "tbl_users")
public class Users {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 50)
    private String username;

    @Column(nullable = false)
    private String password;

    @Column(nullable = false, unique = true, length = 100)
    private String email;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Roles roles;

    @Column(nullable = false)
    private boolean enable = true;

    @Column(nullable = false)
    private boolean accountNonlocked = true;

    @Column(nullable = false)
    private boolean expiresAt = true;

    @Column(name = "create_at", updatable = false)
    private Instant createAt;

    public Users(String username, String email, String password, Roles roles) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.roles = roles;
        this.enable = true;
        this.accountNonlocked = true;
        this.expiresAt = true;
    }

    @PrePersist
    protected void onCreate() {
        if (createAt == null) {
            createAt = Instant.now();
        }
    }
}
