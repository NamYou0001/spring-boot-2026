package com.you.springsecurity.dto;

import java.time.Instant;

public record SessionResponse(
        String sessionId,
        String deviceInfo,
        String ipAddress,
        Instant createdAt,
        Instant expiresAt
) {}
