package com.you.springsecurity.token;

import java.time.Instant;

public record IssuedAccessToken(
        String token,
        Instant expiresAt
) {}