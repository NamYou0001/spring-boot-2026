package com.you.springsecurity.demo;

import java.util.List;
import java.util.Map;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class DemoController {

    // Public API
    @GetMapping("/public/ping")
    public Map<String, Object> publicApi() {

        return Map.of("message", "Public API", "success", true);
    }

    // Private API
    @GetMapping("/private/me")
    public Map<String, Object> privateApi(Authentication authentication) {

        List<String> authorities = authentication.getAuthorities().stream().map(GrantedAuthority::getAuthority).toList();

        return Map.of("username", authentication.getName(), "authorities", authorities, "authenticated", authentication.isAuthenticated(), "message", "JWT Authentication successful");
    }

    // Admin API
    @GetMapping("/admin/ping")
    public Map<String, Object> adminApi(Authentication authentication) {

        return Map.of("username", authentication.getName(), "message", "Welcome Admin", "success", true);
    }
}